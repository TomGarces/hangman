--INSERT INTO sandbox(int16_value, string_value, bool_value) VALUES(4200, 'hello there, wheres is Caelan', 1)

--UPDATE sandbox SET int32_value = 55 WHERE id = 40;

DELETE FROM sandbox WHERE id = 25;


SELECT * FROM sandbox;


