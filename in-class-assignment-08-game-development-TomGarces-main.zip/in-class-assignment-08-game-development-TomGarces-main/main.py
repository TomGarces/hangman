import pygame

# section 01: pregame setup
pygame.init()

monitor_display = (840,690)

game_display = pygame.display.set_mode(monitor_display)

pygame.display.set_caption("Tank Domination")

system_clock = pygame.time.Clock()   




#section 02: game properties
game_properties = {
    "sky":{
     "color": (115)
    }
}


#section 03: reset game properties logic

# section 04: draw tank logic

#section 05: draw heads up display logic

# section 06: projecting shooting logic

# section 07: computer controls logic 

#section 08: Game logic
game_running_flag = True

while game_running_flag: 

    # section 08A: stopping the game
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_running_flag = False
    if not game_running_flag:
        pygame.quit()
        break

          


    # section 08B: deteting key presses and movement

    # section 08C: rendering background graphics
    game_display.fill(game_properties["sky"]["color"])

    # section 08D: rendering tank graphics

    # section 08E: rendering the heads up display graphics

    # section 08f: refreshing game graphics
    pygame.display.update()

    system_clock.tick(30)

